# PowerDZ Store (Node.js + SQLite)

## تشغيل محلي
npm install
npm run create-admin      # ينشئ حساب صاحب المتجر (مرة واحدة)
npm start                 # http://localhost:3000  |  لوحة التحكم: /admin

## النشر (Railway / Render / VPS)
- المتغيرات: NODE_ENV=production ، DATA_DIR=/data (مسار قرص دائم Volume) ، PORT (تلقائي)
- أمر التشغيل: npm start ، وفعّل HTTPS (توفره المنصات تلقائيًا)
- بعد أول نشر افتح Shell المنصة ونفّذ: npm run create-admin
- بدون قرص دائم ستضيع الطلبات والصور عند كل إعادة نشر!

## الأمان
- لا يوجد تسجيل عام: حساب واحد فقط، كلمة السر مشفرة (bcrypt) في قاعدة البيانات.
- جلسة كوكي HttpOnly + SameSite=Strict + Secure، وكل مسارات /api/admin تتطلب الجلسة.
- الأسعار والمخزون يُحسبان في الخادم عند الطلب، لا من المتصفح.
- لتغيير كلمة السر أو عند الشك بالاختراق: npm run create-admin -- --reset
