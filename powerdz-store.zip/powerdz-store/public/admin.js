const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => '&#' + c.charCodeAt(0) + ';');
const D = n => Number(n).toLocaleString('fr-DZ') + ' د.ج';
const CAT = ['تيشيرتات', 'هوديز', 'سويتشيرت', 'بناطيل', 'جاكيتات', 'قبعات'];
const COL = ['أسود', 'أبيض', 'رمادي', 'كحلي', 'كاكي', 'أزرق'];
const ST = { new: 'جديد', confirmed: 'تم التأكيد', shipping: 'قيد التوصيل', done: 'مكتمل', canceled: 'ملغى' };
const dt = s => new Date(s.replace(' ', 'T') + 'Z').toLocaleString('fr-DZ');
let PL = [], cur = {};

function toast(m, e) { const t = $('#toast'); t.textContent = m; t.className = 's' + (e ? ' e' : ''); clearTimeout(t.h); t.h = setTimeout(() => t.className = '', 2500); }
async function api(u, o = {}) {
  const h = { 'X-Requested-With': 'pdz' };
  if (o.body && !(o.body instanceof FormData)) { h['Content-Type'] = 'application/json'; o.body = JSON.stringify(o.body); }
  const r = await fetch(u, { ...o, headers: h, credentials: 'same-origin' }), d = await r.json().catch(() => ({}));
  if (!r.ok) { if (r.status === 401 && u !== '/api/admin/login') showLogin(); throw new Error(d.error || 'حدث خطأ'); }
  return d;
}
const showLogin = () => { $('#app').hidden = true; $('#login').hidden = false; };
async function boot() {
  try { const m = await api('/api/admin/me'); $('#me').textContent = m.email; $('#login').hidden = true; $('#app').hidden = false; tab('stats'); }
  catch (e) { showLogin(); }
}
$('#lf').onsubmit = async e => {
  e.preventDefault(); $('#le').textContent = '';
  try { await api('/api/admin/login', { method: 'POST', body: { email: e.target.email.value, password: e.target.password.value } }); e.target.password.value = ''; boot(); }
  catch (x) { $('#le').textContent = x.message; }
};
$('#out').onclick = async () => { await api('/api/admin/logout', { method: 'POST' }).catch(() => {}); showLogin(); };

const T = { stats, products, orders, messages };
function tab(n) { document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.t === n)); T[n]().catch(x => toast(x.message, 1)); }
document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => tab(b.dataset.t));

// ---------- الإحصائيات ----------
async function stats() {
  const s = await api('/api/admin/stats');
  $('#v').innerHTML = `<div class="st">${[['كل الطلبات', s.orders], ['طلبات جديدة', s.fresh], ['المبيعات (بدون الملغاة)', D(s.revenue)], ['مبيعات مكتملة', D(s.done)], ['المنتجات', s.products], ['مخزون منخفض (≤3)', s.low]]
    .map(x => `<div><small>${x[0]}</small><b>${x[1]}</b></div>`).join('')}</div>`;
}

// ---------- المنتجات ----------
async function products() {
  PL = await api('/api/admin/products');
  $('#v').innerHTML = `<button class="btn a" onclick="edit()" style="margin-bottom:8px">+ منتج جديد</button>` + (PL.map(p => `<div class="it">
    ${p.images[0] ? `<img src="${esc(p.images[0])}" alt="">` : '<div class="ph"></div>'}
    <div><b>${esc(p.name)}</b><br><small>${D(p.price)}${p.discount ? ` · تخفيض ${p.discount}%${p.sale_end ? ' حتى ' + esc(p.sale_end) : ''}` : ''} · المخزون: ${p.stock}</small><br>
    <span class="bg ${p.visible ? 'on' : ''}">${p.visible ? 'ظاهر' : 'مخفي'}</span> <span class="bg">${CAT[p.cat]}</span></div>
    <div class="acts"><button class="btn o s" onclick="edit(${p.id})">تعديل</button><button class="btn o s" onclick="tog(${p.id})">${p.visible ? 'إخفاء' : 'إظهار'}</button><button class="btn d s" onclick="del(${p.id})">حذف</button></div></div>`).join('') || '<p>لا توجد منتجات بعد.</p>');
}
async function tog(id) { const p = PL.find(x => x.id === id); try { await api('/api/admin/products/' + id, { method: 'PUT', body: { ...p, visible: !p.visible } }); products(); } catch (x) { toast(x.message, 1); } }
async function del(id) { if (!confirm('حذف المنتج نهائيًا؟ (يمكنك إخفاؤه بدل ذلك)')) return; try { await api('/api/admin/products/' + id, { method: 'DELETE' }); toast('تم الحذف'); products(); } catch (x) { toast(x.message, 1); } }
function edit(id) {
  cur = id ? JSON.parse(JSON.stringify(PL.find(x => x.id === id))) : { name: '', cat: 0, price: '', discount: 0, sale_end: '', stock: 10, sizes: [], colors: [], images: [], description: '', visible: 1 };
  $('#dlg').innerHTML = `<form class="fm" id="pf"><h3>${id ? 'تعديل المنتج' : 'منتج جديد'}</h3>
  <div><label>الاسم</label><input name="name" value="${esc(cur.name)}" required></div>
  <div class="r2"><div><label>الفئة</label><select name="cat">${CAT.map((c, i) => `<option value="${i}" ${cur.cat == i ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
  <div><label>السعر (د.ج)</label><input name="price" type="number" min="1" value="${esc(cur.price)}" required></div></div>
  <div class="r2"><div><label>تخفيض %  (0 = بدون)</label><input name="discount" type="number" min="0" max="90" value="${cur.discount}"></div>
  <div><label>ينتهي التخفيض (اختياري)</label><input name="sale_end" type="date" value="${esc(cur.sale_end || '')}"></div></div>
  <div class="r2"><div><label>المخزون</label><input name="stock" type="number" min="0" value="${cur.stock}"></div>
  <div><label>المقاسات (مفصولة بفاصلة)</label><input name="sizes" value="${esc(cur.sizes.join(','))}" placeholder="S,M,L,XL"></div></div>
  <div><label>الألوان</label><div class="ch">${COL.map(c => `<label><input type="checkbox" name="cl" value="${c}" ${cur.colors.includes(c) ? 'checked' : ''}>${c}</label>`).join('')}</div></div>
  <div><label>الوصف</label><textarea name="description" rows="3">${esc(cur.description)}</textarea></div>
  <div><label>الصور (الأولى هي الرئيسية)</label><div class="im" id="ims"></div><input type="file" id="fi" accept="image/jpeg,image/png,image/webp" multiple style="margin-top:6px"></div>
  <label class="ch"><input type="checkbox" name="visible" ${cur.visible ? 'checked' : ''} style="width:auto"> ظاهر في المتجر</label>
  <div class="acts"><button type="button" class="btn o" onclick="$('#dlg').close()">إلغاء</button><button class="btn a">حفظ</button></div></form>`;
  imgs(); $('#dlg').showModal();
  $('#fi').onchange = async e => {
    const fd = new FormData(); [...e.target.files].forEach(f => fd.append('files', f));
    try { toast('جارٍ الرفع…'); const r = await api('/api/admin/upload', { method: 'POST', body: fd }); cur.images.push(...r.urls); imgs(); toast('تم رفع الصور ✓'); }
    catch (x) { toast(x.message, 1); } e.target.value = '';
  };
  $('#pf').onsubmit = async e => {
    e.preventDefault(); const f = e.target;
    const body = { name: f.name.value, cat: +f.cat.value, price: +f.price.value, discount: +f.discount.value, sale_end: f.sale_end.value, stock: +f.stock.value,
      sizes: f.sizes.value.split(',').map(s => s.trim()).filter(Boolean), colors: [...f.querySelectorAll('[name=cl]:checked')].map(c => c.value),
      images: cur.images, description: f.description.value, visible: f.visible.checked };
    try { await api('/api/admin/products' + (id ? '/' + id : ''), { method: id ? 'PUT' : 'POST', body }); $('#dlg').close(); toast('تم الحفظ ✓ ويظهر الآن في المتجر'); products(); }
    catch (x) { toast(x.message, 1); }
  };
}
function imgs() {
  $('#ims').innerHTML = cur.images.map((u, i) => `<div><img src="${esc(u)}" alt="" ${i ? `onclick="mainImg(${i})" title="اجعلها رئيسية"` : ''}><button type="button" onclick="rmImg(${i})" aria-label="حذف">×</button></div>`).join('') || '<small>لا توجد صور (سيظهر رسم بديل)</small>';
}
const rmImg = i => { cur.images.splice(i, 1); imgs(); };
const mainImg = i => { cur.images.unshift(cur.images.splice(i, 1)[0]); imgs(); };

// ---------- الطلبات ----------
async function orders() {
  $('#v').innerHTML = `<div class="bar"><input id="oq" placeholder="بحث: الاسم، الهاتف، رقم الطلب" oninput="ol()"><select id="os" onchange="ol()"><option value="">كل الحالات</option>${Object.entries(ST).map(([k, v]) => `<option value="${k}">${v}</option>`).join('')}</select></div><div id="ol"></div>`;
  ol(0);
}
let ot;
function ol(delay = 250) {
  clearTimeout(ot);
  ot = setTimeout(async () => {
    try {
      const d = await api('/api/admin/orders?q=' + encodeURIComponent($('#oq').value) + '&status=' + $('#os').value);
      $('#ol').innerHTML = d.map(o => `<div class="oc"><header><b>${esc(o.no)}</b><select onchange="setSt(${o.id},this.value)">${Object.entries(ST).map(([k, v]) => `<option value="${k}" ${o.status === k ? 'selected' : ''}>${v}</option>`).join('')}</select></header>
      <small>${dt(o.created)}</small><div>👤 ${esc(o.name)} · <a href="tel:${esc(o.phone)}">${esc(o.phone)}</a></div>
      <div>📍 ${esc(o.wilaya)} - ${esc(o.commune)} - ${esc(o.address)}</div>${o.note ? `<div>📝 ${esc(o.note)}</div>` : ''}
      <div>🚚 ${o.delivery === 'desk' ? 'مكتب' : 'منزل'} (${D(o.fee)})</div>
      <ul style="padding-inline-start:18px">${o.items.map(i => `<li>${esc(i.name)} · ${esc(i.s)} · ${esc(i.c)} × ${i.q} = ${D(i.price * i.q)}</li>`).join('')}</ul><b>الإجمالي: ${D(o.total)}</b></div>`).join('') || '<p>لا توجد طلبات مطابقة.</p>';
    } catch (x) { toast(x.message, 1); }
  }, delay);
}
async function setSt(id, st) { try { await api('/api/admin/orders/' + id, { method: 'PATCH', body: { status: st } }); toast('تم تحديث الحالة ✓'); } catch (x) { toast(x.message, 1); ol(0); } }

// ---------- الرسائل ----------
async function messages() {
  const d = await api('/api/admin/messages');
  $('#v').innerHTML = d.map(m => `<div class="oc"><header><b>${esc(m.name)}</b><small>${dt(m.created)}</small></header><small>${esc(m.contact)}</small><p>${esc(m.message)}</p></div>`).join('') || '<p>لا توجد رسائل.</p>';
}
boot();
