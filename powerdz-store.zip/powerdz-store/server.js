const express = require('express'), helmet = require('helmet'), rateLimit = require('express-rate-limit'),
  cookieParser = require('cookie-parser'), bcrypt = require('bcryptjs'), multer = require('multer'),
  crypto = require('crypto'), path = require('path');
const { db, DIR } = require('./db');
const prod = process.env.NODE_ENV === 'production', J = s => JSON.parse(s), app = express();
if (prod) app.set('trust proxy', 1); // خلف Nginx/Railway/Render لضمان عمل الكوكي الآمن
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'", "'unsafe-inline'"], scriptSrcAttr: ["'unsafe-inline'"],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ['https://fonts.gstatic.com'],
  imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], frameAncestors: ["'none'"], formAction: ["'self'"],
  upgradeInsecureRequests: prod ? [] : null } } }));
app.use(express.json({ limit: '100kb' }), cookieParser());
const lim = (min, max) => rateLimit({ windowMs: min * 6e4, max, standardHeaders: true, legacyHeaders: false, message: { error: 'محاولات كثيرة، حاول لاحقًا' } });

// ---------- أدوات ----------
const today = () => new Date().toISOString().slice(0, 10);
const pub = p => { // المنتج كما يراه الزبون (السعر بعد التخفيض يُحسب في الخادم)
  const on = p.discount > 0 && (!p.sale_end || p.sale_end >= today());
  return { id: p.id, n: p.name, c: p.cat, p: on ? Math.round(p.price * (100 - p.discount) / 100) : p.price, o: on ? p.price : null,
    cl: J(p.colors), s: J(p.sizes), images: J(p.images), d: p.description, stock: p.stock, b: p.sold, w: p.id };
};
const fee = (sub, dm) => sub >= 15000 ? 0 : dm === 'desk' ? 400 : 700;
const S = x => String(x ?? '').trim();

// ---------- واجهة الزبائن (عامة) ----------
app.get('/api/products', (req, res) => res.json(db.prepare('SELECT * FROM products WHERE visible=1 ORDER BY id DESC').all().map(pub)));

app.post('/api/orders', lim(60, 10), (req, res) => {
  const b = req.body || {}, name = S(b.name).slice(0, 80), phone = S(b.phone), wil = S(b.wilaya).slice(0, 40),
    com = S(b.commune).slice(0, 60), addr = S(b.address).slice(0, 200), note = S(b.note).slice(0, 300), dm = b.delivery === 'desk' ? 'desk' : 'home';
  if (name.length < 3 || !/^0[567]\d{8}$/.test(phone) || !wil || !com || addr.length < 5 || !Array.isArray(b.items) || !b.items.length || b.items.length > 30)
    return res.status(400).json({ error: 'بيانات الطلب غير صالحة' });
  try {
    const out = db.transaction(() => {
      let sub = 0; const lines = [];
      for (const it of b.items) { // الأسعار تُقرأ من قاعدة البيانات فقط، لا من المتصفح
        const p = db.prepare('SELECT * FROM products WHERE id=? AND visible=1').get(+it.id), q = Math.floor(+it.q);
        if (!p || !(q >= 1 && q <= 10)) throw { user: 'منتج غير متوفر، حدّث السلة' };
        if (!J(p.sizes).includes(it.s) || !J(p.colors).includes(it.c)) throw { user: 'خيار غير متوفر: ' + p.name };
        if (!db.prepare('UPDATE products SET stock=stock-?, sold=sold+? WHERE id=? AND stock>=?').run(q, q, p.id, q).changes) throw { user: 'نفد المخزون: ' + p.name };
        const price = pub(p).p; sub += price * q; lines.push({ id: p.id, name: p.name, s: it.s, c: it.c, q, price });
      }
      const f = fee(sub, dm), no = 'DZ' + crypto.randomInt(100000, 999999);
      db.prepare('INSERT INTO orders(no,name,phone,wilaya,commune,address,note,delivery,fee,subtotal,total,items) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')
        .run(no, name, phone, wil, com, addr, note, dm, f, sub, sub + f, JSON.stringify(lines));
      return { no, total: sub + f };
    })();
    res.json(out);
  } catch (e) { e.user ? res.status(400).json({ error: e.user }) : (console.error(e), res.status(500).json({ error: 'خطأ في الخادم' })); }
});

app.post('/api/messages', lim(60, 5), (req, res) => {
  const b = req.body || {}, n = S(b.name).slice(0, 80), c = S(b.contact).slice(0, 100), m = S(b.message).slice(0, 1000);
  if (n.length < 2 || c.length < 5 || m.length < 10) return res.status(400).json({ error: 'بيانات غير صالحة' });
  db.prepare('INSERT INTO messages(name,contact,message) VALUES(?,?,?)').run(n, c, m); res.json({ ok: 1 });
});

// ---------- الإدارة: تسجيل الدخول ----------
const hash = t => crypto.createHash('sha256').update(t).digest('hex');
const DUMMY = bcrypt.hashSync('x', 12);
// حماية CSRF: الكوكي SameSite=Strict + ترويسة مخصصة لا يمكن لموقع آخر إرسالها
app.use('/api/admin', (req, res, next) => { res.set('Cache-Control', 'no-store'); req.get('X-Requested-With') === 'pdz' ? next() : res.status(403).json({ error: 'forbidden' }); });

app.post('/api/admin/login', lim(15, 8), (req, res) => {
  const a = db.prepare('SELECT * FROM admin WHERE email=?').get(S(req.body?.email).toLowerCase());
  const ok = bcrypt.compareSync(S(req.body?.password), a ? a.hash : DUMMY);
  if (!a || !ok) return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  const t = crypto.randomBytes(32).toString('hex');
  db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());
  db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(hash(t), a.id, Date.now() + 7 * 864e5);
  res.cookie('sid', t, { httpOnly: true, sameSite: 'strict', secure: prod, maxAge: 7 * 864e5, path: '/' }).json({ ok: 1 });
});

// كل ما بعد هذا السطر يتطلب جلسة مدير صالحة
app.use('/api/admin', (req, res, next) => {
  const t = req.cookies.sid, r = t && db.prepare('SELECT a.id, a.email FROM sessions s JOIN admin a ON a.id=s.admin_id WHERE s.token=? AND s.expires>?').get(hash(t), Date.now());
  r ? (req.admin = r, next()) : res.status(401).json({ error: 'unauthorized' });
});
app.get('/api/admin/me', (req, res) => res.json({ email: req.admin.email }));
app.post('/api/admin/logout', (req, res) => { db.prepare('DELETE FROM sessions WHERE token=?').run(hash(req.cookies.sid)); res.clearCookie('sid').json({ ok: 1 }); });

// ---------- الإدارة: المنتجات ----------
const arr = (a, max, len = 30) => (Array.isArray(a) ? a : []).map(x => S(x).slice(0, len)).filter(Boolean).slice(0, max);
function clean(b) {
  const n = S(b.name).slice(0, 100), price = Math.round(+b.price), disc = Math.round(+b.discount || 0), stock = Math.round(+b.stock || 0), cat = Math.round(+b.cat || 0);
  if (!n || !(price > 0) || disc < 0 || disc > 90 || stock < 0 || cat < 0 || cat > 5) return null;
  const imgs = arr(b.images, 8, 80).filter(u => /^\/uploads\/[\w-]+\.(jpg|png|webp)$/.test(u));
  const se = /^\d{4}-\d{2}-\d{2}$/.test(b.sale_end || '') ? b.sale_end : null;
  return [n, cat, price, disc, se, stock, JSON.stringify(arr(b.sizes, 12)), JSON.stringify(arr(b.colors, 10)), JSON.stringify(imgs), S(b.description).slice(0, 2000), b.visible ? 1 : 0];
}
const cols = 'name,cat,price,discount,sale_end,stock,sizes,colors,images,description,visible';
app.get('/api/admin/products', (req, res) => res.json(db.prepare('SELECT * FROM products ORDER BY id DESC').all().map(p => ({ ...p, sizes: J(p.sizes), colors: J(p.colors), images: J(p.images) }))));
app.post('/api/admin/products', (req, res) => { const v = clean(req.body); if (!v) return res.status(400).json({ error: 'تحقق من الاسم والسعر والتخفيض والمخزون' });
  res.json({ id: db.prepare(`INSERT INTO products(${cols}) VALUES(${v.map(() => '?')})`).run(...v).lastInsertRowid }); });
app.put('/api/admin/products/:id', (req, res) => { const v = clean(req.body); if (!v) return res.status(400).json({ error: 'تحقق من الاسم والسعر والتخفيض والمخزون' });
  db.prepare(`UPDATE products SET ${cols.split(',').map(c => c + '=?')} WHERE id=?`).run(...v, +req.params.id); res.json({ ok: 1 }); });
app.delete('/api/admin/products/:id', (req, res) => { db.prepare('DELETE FROM products WHERE id=?').run(+req.params.id); res.json({ ok: 1 }); });

// رفع الصور: jpg/png/webp فقط، حتى 5MB، أسماء عشوائية
const EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
const up = multer({ limits: { fileSize: 5e6, files: 8 }, fileFilter: (r, f, cb) => cb(EXT[f.mimetype] ? null : new Error('الصيغ المسموحة: JPG, PNG, WEBP'), !!EXT[f.mimetype]),
  storage: multer.diskStorage({ destination: path.join(DIR, 'uploads'), filename: (r, f, cb) => cb(null, crypto.randomBytes(16).toString('hex') + '.' + EXT[f.mimetype]) }) });
app.post('/api/admin/upload', up.array('files', 8), (req, res) => res.json({ urls: req.files.map(f => '/uploads/' + f.filename) }));

// ---------- الإدارة: الطلبات والإحصائيات ----------
const ST = ['new', 'confirmed', 'shipping', 'done', 'canceled'];
app.get('/api/admin/orders', (req, res) => {
  const q = '%' + S(req.query.q).replace(/[%_]/g, '') + '%', st = ST.includes(req.query.status) ? req.query.status : '%';
  res.json(db.prepare('SELECT * FROM orders WHERE status LIKE ? AND (name LIKE ? OR phone LIKE ? OR no LIKE ?) ORDER BY id DESC LIMIT 300').all(st, q, q, q).map(o => ({ ...o, items: J(o.items) })));
});
app.patch('/api/admin/orders/:id', (req, res) => {
  const st = req.body?.status, o = db.prepare('SELECT * FROM orders WHERE id=?').get(+req.params.id);
  if (!ST.includes(st) || !o) return res.status(400).json({ error: 'طلب غير صالح' });
  if (o.status === 'canceled' && st !== 'canceled') return res.status(400).json({ error: 'الطلب الملغى لا يُعاد تفعيله' });
  db.transaction(() => { // عند الإلغاء يعود المخزون تلقائيًا
    if (st === 'canceled' && o.status !== 'canceled') for (const l of J(o.items)) db.prepare('UPDATE products SET stock=stock+?, sold=MAX(0,sold-?) WHERE id=?').run(l.q, l.q, l.id);
    db.prepare('UPDATE orders SET status=? WHERE id=?').run(st, o.id);
  })(); res.json({ ok: 1 });
});
app.get('/api/admin/messages', (req, res) => res.json(db.prepare('SELECT * FROM messages ORDER BY id DESC LIMIT 200').all()));
app.get('/api/admin/stats', (req, res) => {
  const g = (q, ...a) => db.prepare(q).get(...a).c;
  res.json({ orders: g('SELECT COUNT(*) c FROM orders'), fresh: g("SELECT COUNT(*) c FROM orders WHERE status='new'"),
    revenue: g("SELECT COALESCE(SUM(total),0) c FROM orders WHERE status!='canceled'"), done: g("SELECT COALESCE(SUM(total),0) c FROM orders WHERE status='done'"),
    products: g('SELECT COUNT(*) c FROM products'), low: g('SELECT COUNT(*) c FROM products WHERE stock<=3') });
});

// ---------- الملفات الثابتة ----------
app.use('/uploads', express.static(path.join(DIR, 'uploads'), { maxAge: '7d' }));
app.get(['/admin', '/admin/'], (req, res) => res.set('X-Robots-Tag', 'noindex').sendFile(path.join(__dirname, 'public/admin.html')));
app.use(express.static(path.join(__dirname, 'public')));
app.use((e, req, res, next) => { console.error(e.message); res.status(400).json({ error: e.message || 'خطأ' }); });
app.listen(process.env.PORT || 3000, () => console.log('PowerDZ running on port ' + (process.env.PORT || 3000)));
