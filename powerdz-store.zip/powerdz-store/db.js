const Database = require('better-sqlite3'), path = require('path'), fs = require('fs');
// DATA_DIR: مجلد قاعدة البيانات والصور. في الإنتاج اجعله على قرص دائم (Volume)
const DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(path.join(DIR, 'uploads'), { recursive: true });
const db = new Database(path.join(DIR, 'store.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS admin(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, admin_id INTEGER NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, cat INTEGER NOT NULL DEFAULT 0,
  price INTEGER NOT NULL, discount INTEGER NOT NULL DEFAULT 0, sale_end TEXT, stock INTEGER NOT NULL DEFAULT 0,
  sizes TEXT NOT NULL DEFAULT '[]', colors TEXT NOT NULL DEFAULT '[]', images TEXT NOT NULL DEFAULT '[]',
  description TEXT DEFAULT '', visible INTEGER NOT NULL DEFAULT 1, sold INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT, no TEXT UNIQUE, name TEXT, phone TEXT, wilaya TEXT,
  commune TEXT, address TEXT, note TEXT, delivery TEXT, fee INTEGER, subtotal INTEGER, total INTEGER, items TEXT,
  status TEXT NOT NULL DEFAULT 'new', created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, contact TEXT, message TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP);
`);

if (!db.prepare('SELECT 1 FROM products').get()) {
  const S5 = 'S,M,L,XL,XXL', S4 = 'S,M,L,XL', SP = '30,32,34,36', OS = 'موحد';
  // [الاسم, الفئة, السعر, التخفيض %, المخزون, المقاسات, الألوان]
  const seed = [
    ['تيشيرت Oversize Street', 0, 3500, 20, 40, S5, 'أسود,أبيض,رمادي'], ['هودي Core Heavy', 1, 6200, 0, 25, S5, 'أسود,رمادي,كحلي'],
    ['سويتشيرت Crewneck', 2, 4800, 0, 30, S4, 'رمادي,كاكي,أسود'], ['بنطلون Cargo Utility', 3, 6900, 0, 20, SP, 'كاكي,أسود'],
    ['جينز Baggy Fit', 3, 7500, 13, 20, SP, 'أزرق,أسود'], ['جاكيت Bomber DZ', 4, 9800, 0, 15, S4, 'أسود,كاكي'],
    ['قبعة Snapback Logo', 5, 1800, 0, 50, OS, 'أسود,أبيض,كحلي'], ['تيشيرت Graphic Wave', 0, 3200, 0, 40, S4, 'أبيض,أسود'],
    ['هودي Zip Up', 1, 8000, 14, 20, S5, 'رمادي,أسود'], ['جينز Straight Classic', 3, 6200, 0, 20, SP, 'أزرق,كحلي'],
    ['جاكيت Denim Washed', 4, 8900, 0, 12, S4, 'أزرق,أسود'], ['قبعة Trucker Mesh', 5, 1600, 0, 50, OS, 'أسود,كاكي']];
  const ins = db.prepare('INSERT INTO products(name,cat,price,discount,stock,sizes,colors) VALUES(?,?,?,?,?,?,?)');
  db.transaction(() => seed.forEach(r => ins.run(r[0], r[1], r[2], r[3], r[4], JSON.stringify(r[5].split(',')), JSON.stringify(r[6].split(',')))))();
}
module.exports = { db, DIR };
