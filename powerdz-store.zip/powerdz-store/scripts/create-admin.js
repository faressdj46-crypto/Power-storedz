// إنشاء حساب صاحب المتجر (حساب واحد فقط). لا يوجد تسجيل عام في الموقع.
// الاستعمال:  npm run create-admin          (أول مرة)
//            npm run create-admin -- --reset  (تغيير الحساب/كلمة السر ونسيان الجلسات القديمة)
const readline = require('readline'), bcrypt = require('bcryptjs'), { db } = require('../db');
const reset = process.argv.includes('--reset');
if (db.prepare('SELECT 1 FROM admin').get() && !reset) {
  console.log('يوجد حساب مدير بالفعل. لتغييره شغّل: npm run create-admin -- --reset'); process.exit(1);
}
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
let mute = false;
rl._writeToOutput = s => { if (!mute || s.includes('\n')) rl.output.write(s); }; // إخفاء كلمة السر أثناء الكتابة
const ask = (t, m) => new Promise(r => { rl.question(t, a => { mute = false; r(a.trim()); }); mute = !!m; });
(async () => {
  const email = (await ask('بريد المدير: ')).toLowerCase();
  const pw = await ask('كلمة السر (12 حرفًا على الأقل): ', true), pw2 = await ask('أعد كتابتها: ', true);
  rl.close();
  if (!/^\S+@\S+\.\S+$/.test(email)) return console.log('بريد غير صالح'), process.exit(1);
  if (pw.length < 12 || pw !== pw2) return console.log('كلمة السر قصيرة أو غير متطابقة'), process.exit(1);
  db.transaction(() => { db.prepare('DELETE FROM sessions').run(); db.prepare('DELETE FROM admin').run();
    db.prepare('INSERT INTO admin(email,hash) VALUES(?,?)').run(email, bcrypt.hashSync(pw, 12)); })();
  console.log('\n✓ تم إنشاء حساب المدير: ' + email);
})();
